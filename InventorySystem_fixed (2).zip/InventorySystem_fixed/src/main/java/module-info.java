module com.inventory {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.xerial.sqlitejdbc;

    opens com.inventory to javafx.fxml;
    opens com.inventory.model to javafx.base;
    opens com.inventory.view to javafx.fxml;
    opens com.inventory.controller to javafx.fxml;

    exports com.inventory;
    exports com.inventory.model;
    exports com.inventory.view;
    exports com.inventory.controller;
    exports com.inventory.dao;
    exports com.inventory.util;
    exports com.inventory.database;
}
