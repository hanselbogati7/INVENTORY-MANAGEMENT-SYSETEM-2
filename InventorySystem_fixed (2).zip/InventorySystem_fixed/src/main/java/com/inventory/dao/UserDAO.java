package com.inventory.dao;

import com.inventory.database.DatabaseConnection;
import com.inventory.model.User;
import java.sql.*;
import java.util.*;

public class UserDAO {
    private Connection conn() { return DatabaseConnection.getInstance().getConnection(); }

    public User authenticate(String username, String password) {
        try (PreparedStatement ps = conn().prepareStatement(
                "SELECT * FROM users WHERE username=? AND password=?")) {
            ps.setString(1, username); ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return null;
    }

    public List<User> getAll() {
        List<User> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM users ORDER BY user_id")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return list;
    }

    public boolean insert(User u) {
        try (PreparedStatement ps = conn().prepareStatement(
                "INSERT INTO users (username, password, role) VALUES (?,?,?)")) {
            ps.setString(1, u.getUsername()); ps.setString(2, u.getPassword());
            ps.setString(3, u.getRole());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    public boolean update(User u) {
        try (PreparedStatement ps = conn().prepareStatement(
                "UPDATE users SET username=?, password=?, role=? WHERE user_id=?")) {
            ps.setString(1, u.getUsername()); ps.setString(2, u.getPassword());
            ps.setString(3, u.getRole());     ps.setInt(4, u.getUserId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    public boolean delete(int id) {
        try (PreparedStatement ps = conn().prepareStatement(
                "DELETE FROM users WHERE user_id=?")) {
            ps.setInt(1, id); return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    private User map(ResultSet rs) throws SQLException {
        return new User(rs.getInt("user_id"), rs.getString("username"),
                        rs.getString("password"), rs.getString("role"));
    }
}
