package com.inventory.dao;

import com.inventory.database.DatabaseConnection;
import com.inventory.model.Alert;
import java.sql.*;
import java.util.*;

public class AlertDAO {
    private Connection conn() { return DatabaseConnection.getInstance().getConnection(); }

    private static final String SELECT_JOINED =
        "SELECT a.*, p.product_name FROM alerts a " +
        "LEFT JOIN products p ON a.product_id = p.product_id ";

    public List<Alert> getAll() {
        List<Alert> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery(SELECT_JOINED + "ORDER BY a.created_at DESC")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return list;
    }

    public List<Alert> getActive() {
        List<Alert> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery(SELECT_JOINED + "WHERE a.is_resolved=0 ORDER BY a.created_at DESC")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return list;
    }

    public int getActiveCount() {
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM alerts WHERE is_resolved=0")) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return 0;
    }

    public boolean insert(Alert a) {
        try (PreparedStatement ps = conn().prepareStatement(
                "INSERT INTO alerts (product_id, alert_type, message) VALUES (?,?,?)")) {
            ps.setInt(1, a.getProductId()); ps.setString(2, a.getAlertType());
            ps.setString(3, a.getMessage());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    public boolean resolve(int alertId) {
        try (PreparedStatement ps = conn().prepareStatement(
                "UPDATE alerts SET is_resolved=1 WHERE alert_id=?")) {
            ps.setInt(1, alertId); return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    /** Auto-generate alerts for all low/out-of-stock products */
    public void syncAlerts() {
        String sql = "SELECT product_id, product_name, quantity, reorder_level FROM products WHERE status='Active'";
        try (ResultSet rs = conn().createStatement().executeQuery(sql)) {
            while (rs.next()) {
                int qty  = rs.getInt("quantity");
                int rl   = rs.getInt("reorder_level");
                int pid  = rs.getInt("product_id");
                String nm = rs.getString("product_name");
                if (qty == 0) {
                    ensureAlert(pid, "Out of Stock", nm + " is out of stock (0 units)");
                } else if (qty <= rl) {
                    ensureAlert(pid, "Low Stock", nm + " is below reorder level (" + qty + " < " + rl + ")");
                }
            }
        } catch (SQLException e) { System.err.println(e.getMessage()); }
    }

    private void ensureAlert(int productId, String type, String msg) throws SQLException {
        try (PreparedStatement check = conn().prepareStatement(
                "SELECT COUNT(*) FROM alerts WHERE product_id=? AND alert_type=? AND is_resolved=0")) {
            check.setInt(1, productId); check.setString(2, type);
            try (ResultSet rs = check.executeQuery()) {
                if (rs.next() && rs.getInt(1) == 0) {
                    Alert a = new Alert(); a.setProductId(productId);
                    a.setAlertType(type); a.setMessage(msg);
                    insert(a);
                }
            }
        }
    }

    private Alert map(ResultSet rs) throws SQLException {
        Alert a = new Alert(rs.getInt("alert_id"), rs.getInt("product_id"),
            rs.getString("product_name"), rs.getString("alert_type"),
            rs.getString("message"), rs.getString("created_at"),
            rs.getInt("is_resolved") == 1);
        return a;
    }
}
