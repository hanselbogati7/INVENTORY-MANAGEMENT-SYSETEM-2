package com.inventory.dao;

import com.inventory.database.DatabaseConnection;
import com.inventory.model.*;
import java.sql.*;
import java.util.*;

public class SupplierDAO {
    private Connection conn() { return DatabaseConnection.getInstance().getConnection(); }

    public List<Supplier> getAll() {
        List<Supplier> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM suppliers ORDER BY supplier_id")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return list;
    }

    public boolean insert(Supplier s) {
        try (PreparedStatement ps = conn().prepareStatement(
                "INSERT INTO suppliers (supplier_name, contact_info, email, address) VALUES (?,?,?,?)")) {
            ps.setString(1, s.getSupplierName()); ps.setString(2, s.getContactInfo());
            ps.setString(3, s.getEmail());         ps.setString(4, s.getAddress());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    public boolean update(Supplier s) {
        try (PreparedStatement ps = conn().prepareStatement(
                "UPDATE suppliers SET supplier_name=?, contact_info=?, email=?, address=? WHERE supplier_id=?")) {
            ps.setString(1, s.getSupplierName()); ps.setString(2, s.getContactInfo());
            ps.setString(3, s.getEmail());         ps.setString(4, s.getAddress());
            ps.setInt(5, s.getSupplierId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    public boolean delete(int id) {
        try (PreparedStatement ps = conn().prepareStatement(
                "DELETE FROM suppliers WHERE supplier_id=?")) {
            ps.setInt(1, id); return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    private Supplier map(ResultSet rs) throws SQLException {
        return new Supplier(rs.getInt("supplier_id"), rs.getString("supplier_name"),
                            rs.getString("contact_info"), rs.getString("email"), rs.getString("address"));
    }
}
