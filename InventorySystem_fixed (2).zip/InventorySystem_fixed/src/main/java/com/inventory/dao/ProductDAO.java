package com.inventory.dao;

import com.inventory.database.DatabaseConnection;
import com.inventory.model.Product;
import java.sql.*;
import java.util.*;

public class ProductDAO {
    private Connection conn() { return DatabaseConnection.getInstance().getConnection(); }

    private static final String SELECT_WITH_SUPPLIER =
        "SELECT p.*, s.supplier_name FROM products p " +
        "LEFT JOIN suppliers s ON p.supplier_id = s.supplier_id ";

    public List<Product> getAll() {
        List<Product> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery(SELECT_WITH_SUPPLIER + "ORDER BY p.product_id")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return list;
    }

    public List<Product> getActive() {
        List<Product> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery(SELECT_WITH_SUPPLIER + "WHERE p.status='Active' ORDER BY p.product_id")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return list;
    }

    public List<Product> search(String keyword) {
        List<Product> list = new ArrayList<>();
        String sql = SELECT_WITH_SUPPLIER +
            "WHERE p.product_name LIKE ? OR p.category LIKE ? OR CAST(p.product_id AS TEXT) LIKE ?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            String k = "%" + keyword + "%";
            ps.setString(1, k); ps.setString(2, k); ps.setString(3, k);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return list;
    }

    public List<Product> getLowStock() {
        List<Product> list = new ArrayList<>();
        String sql = SELECT_WITH_SUPPLIER +
            "WHERE p.quantity <= p.reorder_level AND p.status='Active' ORDER BY p.quantity";
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return list;
    }

    public Product getById(int id) {
        try (PreparedStatement ps = conn().prepareStatement(
                SELECT_WITH_SUPPLIER + "WHERE p.product_id=?")) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return null;
    }

    public boolean insert(Product p) {
        String sql = "INSERT INTO products (product_name, category, quantity, price, " +
                     "reorder_level, supplier_id, purchase_date, status) VALUES (?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1, p.getProductName()); ps.setString(2, p.getCategory());
            ps.setInt(3, p.getQuantity());       ps.setDouble(4, p.getPrice());
            ps.setInt(5, p.getReorderLevel());   ps.setInt(6, p.getSupplierId());
            ps.setString(7, p.getPurchaseDate()); ps.setString(8, p.getStatus());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    public boolean update(Product p) {
        String sql = "UPDATE products SET product_name=?, category=?, quantity=?, price=?, " +
                     "reorder_level=?, supplier_id=?, purchase_date=?, status=? WHERE product_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1, p.getProductName()); ps.setString(2, p.getCategory());
            ps.setInt(3, p.getQuantity());       ps.setDouble(4, p.getPrice());
            ps.setInt(5, p.getReorderLevel());   ps.setInt(6, p.getSupplierId());
            ps.setString(7, p.getPurchaseDate()); ps.setString(8, p.getStatus());
            ps.setInt(9, p.getProductId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    public boolean updateQuantity(int productId, int newQty) {
        try (PreparedStatement ps = conn().prepareStatement(
                "UPDATE products SET quantity=? WHERE product_id=?")) {
            ps.setInt(1, newQty); ps.setInt(2, productId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    public boolean archive(int productId) {
        try (PreparedStatement ps = conn().prepareStatement(
                "UPDATE products SET status='Archived' WHERE product_id=?")) {
            ps.setInt(1, productId); return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    public int getTotalCount() {
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM products WHERE status='Active'")) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return 0;
    }

    public int getLowStockCount() {
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM products WHERE quantity<=reorder_level AND status='Active'")) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return 0;
    }

    public double getTotalInventoryValue() {
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT SUM(quantity * price) FROM products WHERE status='Active'")) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return 0;
    }

    private Product map(ResultSet rs) throws SQLException {
        Product p = new Product(
            rs.getInt("product_id"), rs.getString("product_name"),
            rs.getString("category"), rs.getInt("quantity"),
            rs.getDouble("price"), rs.getInt("reorder_level"),
            rs.getInt("supplier_id"), rs.getString("purchase_date"),
            rs.getString("status"));
        try { p.setSupplierName(rs.getString("supplier_name")); } catch (Exception ignored) {}
        return p;
    }
}
