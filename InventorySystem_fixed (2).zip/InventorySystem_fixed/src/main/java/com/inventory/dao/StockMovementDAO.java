package com.inventory.dao;

import com.inventory.database.DatabaseConnection;
import com.inventory.model.StockMovement;
import java.sql.*;
import java.util.*;

public class StockMovementDAO {
    private Connection conn() { return DatabaseConnection.getInstance().getConnection(); }

    private static final String SELECT_JOINED =
        "SELECT sm.*, p.product_name FROM stock_movements sm " +
        "LEFT JOIN products p ON sm.product_id = p.product_id ";

    public List<StockMovement> getAll() {
        List<StockMovement> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery(SELECT_JOINED + "ORDER BY sm.movement_date DESC")) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return list;
    }

    public List<StockMovement> getRecent(int limit) {
        List<StockMovement> list = new ArrayList<>();
        try (PreparedStatement ps = conn().prepareStatement(
                SELECT_JOINED + "ORDER BY sm.movement_date DESC LIMIT ?")) {
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return list;
    }

    public List<StockMovement> getByProduct(int productId) {
        List<StockMovement> list = new ArrayList<>();
        try (PreparedStatement ps = conn().prepareStatement(
                SELECT_JOINED + "WHERE sm.product_id=? ORDER BY sm.movement_date DESC")) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return list;
    }

    public List<StockMovement> search(String keyword) {
        List<StockMovement> list = new ArrayList<>();
        try (PreparedStatement ps = conn().prepareStatement(
                SELECT_JOINED + "WHERE p.product_name LIKE ? OR sm.movement_type LIKE ? OR sm.notes LIKE ?")) {
            String k = "%" + keyword + "%";
            ps.setString(1, k); ps.setString(2, k); ps.setString(3, k);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { System.err.println(e.getMessage()); }
        return list;
    }

    public boolean insert(StockMovement m) {
        String sql = "INSERT INTO stock_movements (product_id, movement_type, quantity, movement_date, user_id, notes) " +
                     "VALUES (?, ?, ?, datetime('now'), ?, ?)";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, m.getProductId());       ps.setString(2, m.getMovementType());
            ps.setInt(3, m.getQuantity());         ps.setInt(4, m.getUserId());
            ps.setString(5, m.getNotes());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { System.err.println(e.getMessage()); return false; }
    }

    private StockMovement map(ResultSet rs) throws SQLException {
        return new StockMovement(rs.getInt("movement_id"), rs.getInt("product_id"),
            rs.getString("product_name"), rs.getString("movement_type"),
            rs.getInt("quantity"), rs.getString("movement_date"),
            rs.getInt("user_id"), rs.getString("notes"));
    }
}
