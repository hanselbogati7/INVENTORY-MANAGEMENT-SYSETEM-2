package com.inventory.model;

public class Alert {
    private int alertId;
    private int productId;
    private String productName; // joined
    private String alertType;
    private String message;
    private String createdAt;
    private boolean resolved;

    public Alert() {}
    public Alert(int alertId, int productId, String productName,
                 String alertType, String message, String createdAt, boolean resolved) {
        this.alertId = alertId; this.productId = productId;
        this.productName = productName; this.alertType = alertType;
        this.message = message; this.createdAt = createdAt; this.resolved = resolved;
    }

    public int getAlertId()               { return alertId; }
    public void setAlertId(int id)        { this.alertId = id; }
    public int getProductId()             { return productId; }
    public void setProductId(int id)      { this.productId = id; }
    public String getProductName()        { return productName; }
    public void setProductName(String n)  { this.productName = n; }
    public String getAlertType()          { return alertType; }
    public void setAlertType(String t)    { this.alertType = t; }
    public String getMessage()            { return message; }
    public void setMessage(String m)      { this.message = m; }
    public String getCreatedAt()          { return createdAt; }
    public void setCreatedAt(String d)    { this.createdAt = d; }
    public boolean isResolved()           { return resolved; }
    public void setResolved(boolean r)    { this.resolved = r; }
    public String getStatusLabel()        { return resolved ? "Resolved" : "Active"; }
}
