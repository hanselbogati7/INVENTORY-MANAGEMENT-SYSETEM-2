package com.inventory.model;

public class Supplier {
    private int supplierId;
    private String supplierName;
    private String contactInfo;
    private String email;
    private String address;

    public Supplier() {}
    public Supplier(int supplierId, String supplierName, String contactInfo,
                    String email, String address) {
        this.supplierId = supplierId; this.supplierName = supplierName;
        this.contactInfo = contactInfo; this.email = email; this.address = address;
    }

    public int getSupplierId()             { return supplierId; }
    public void setSupplierId(int id)      { this.supplierId = id; }
    public String getSupplierName()        { return supplierName; }
    public void setSupplierName(String n)  { this.supplierName = n; }
    public String getContactInfo()         { return contactInfo; }
    public void setContactInfo(String c)   { this.contactInfo = c; }
    public String getEmail()               { return email; }
    public void setEmail(String e)         { this.email = e; }
    public String getAddress()             { return address; }
    public void setAddress(String a)       { this.address = a; }

    @Override public String toString() { return supplierName; }
}
