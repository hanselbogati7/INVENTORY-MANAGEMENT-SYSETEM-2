package com.inventory.model;

public class StockMovement {
    private int movementId;
    private int productId;
    private String productName; // joined
    private String movementType; // IN or OUT
    private int quantity;
    private String movementDate;
    private int userId;
    private String notes;

    public StockMovement() {}
    public StockMovement(int movementId, int productId, String productName,
                         String movementType, int quantity, String movementDate,
                         int userId, String notes) {
        this.movementId = movementId; this.productId = productId;
        this.productName = productName; this.movementType = movementType;
        this.quantity = quantity; this.movementDate = movementDate;
        this.userId = userId; this.notes = notes;
    }

    public int getMovementId()               { return movementId; }
    public void setMovementId(int id)        { this.movementId = id; }
    public int getProductId()                { return productId; }
    public void setProductId(int id)         { this.productId = id; }
    public String getProductName()           { return productName; }
    public void setProductName(String n)     { this.productName = n; }
    public String getMovementType()          { return movementType; }
    public void setMovementType(String t)    { this.movementType = t; }
    public int getQuantity()                 { return quantity; }
    public void setQuantity(int q)           { this.quantity = q; }
    public String getMovementDate()          { return movementDate; }
    public void setMovementDate(String d)    { this.movementDate = d; }
    public int getUserId()                   { return userId; }
    public void setUserId(int id)            { this.userId = id; }
    public String getNotes()                 { return notes; }
    public void setNotes(String n)           { this.notes = n; }
}
