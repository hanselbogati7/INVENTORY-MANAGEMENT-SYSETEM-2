package com.inventory.model;

/**
 * Item/Product entity. Quantity is private — modified only through
 * addStock() and removeStock() which enforce business rules (Encapsulation).
 */
public class Product {
    private int productId;
    private String productName;
    private String category;
    private int quantity;
    private double price;
    private int reorderLevel;
    private int supplierId;
    private String supplierName; // joined field
    private String purchaseDate;
    private String status;

    public Product() {}

    public Product(int productId, String productName, String category,
                   int quantity, double price, int reorderLevel,
                   int supplierId, String purchaseDate, String status) {
        this.productId = productId; this.productName = productName;
        this.category = category;   this.quantity = quantity;
        this.price = price;         this.reorderLevel = reorderLevel;
        this.supplierId = supplierId; this.purchaseDate = purchaseDate;
        this.status = status;
    }

    /** Add stock — validates positive amount */
    public boolean addStock(int amount) {
        if (amount <= 0) return false;
        quantity += amount;
        return true;
    }

    /** Remove stock — validates availability */
    public boolean removeStock(int amount) {
        if (amount <= 0 || amount > quantity) return false;
        quantity -= amount;
        return true;
    }

    /** True when quantity is at or below reorder level */
    public boolean isLowStock() { return quantity > 0 && quantity <= reorderLevel; }

    /** True when quantity is zero */
    public boolean isOutOfStock() { return quantity == 0; }

    public String getStockStatus() {
        if (isOutOfStock())  return "Out of Stock";
        if (isLowStock())    return "Low Stock";
        return "In Stock";
    }

    public double getInventoryValue() { return quantity * price; }

    // Getters / setters
    public int getProductId()               { return productId; }
    public void setProductId(int id)        { this.productId = id; }
    public String getProductName()          { return productName; }
    public void setProductName(String n)    { this.productName = n; }
    public String getCategory()             { return category; }
    public void setCategory(String c)       { this.category = c; }
    public int getQuantity()                { return quantity; }
    public void setQuantity(int q)          { this.quantity = q; }
    public double getPrice()                { return price; }
    public void setPrice(double p)          { this.price = p; }
    public int getReorderLevel()            { return reorderLevel; }
    public void setReorderLevel(int r)      { this.reorderLevel = r; }
    public int getSupplierId()              { return supplierId; }
    public void setSupplierId(int id)       { this.supplierId = id; }
    public String getSupplierName()         { return supplierName; }
    public void setSupplierName(String s)   { this.supplierName = s; }
    public String getPurchaseDate()         { return purchaseDate; }
    public void setPurchaseDate(String d)   { this.purchaseDate = d; }
    public String getStatus()               { return status; }
    public void setStatus(String s)         { this.status = s; }

    @Override public String toString() { return productName + " (ID: " + productId + ")"; }
}
