package com.inventory.database;

import java.sql.*;

public class DatabaseInitializer {

    public static void initialize() {
        Connection conn = DatabaseConnection.getInstance().getConnection();
        try (Statement s = conn.createStatement()) {

            // Users
            s.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id   INTEGER PRIMARY KEY AUTOINCREMENT,
                    username  VARCHAR(50) UNIQUE NOT NULL,
                    password  VARCHAR(100) NOT NULL,
                    role      VARCHAR(30) NOT NULL
                )""");

            // Suppliers
            s.execute("""
                CREATE TABLE IF NOT EXISTS suppliers (
                    supplier_id   INTEGER PRIMARY KEY AUTOINCREMENT,
                    supplier_name VARCHAR(100) NOT NULL,
                    contact_info  VARCHAR(150),
                    email         VARCHAR(100),
                    address       VARCHAR(200)
                )""");

            // Products (Items)
            s.execute("""
                CREATE TABLE IF NOT EXISTS products (
                    product_id    INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_name  VARCHAR(100) NOT NULL,
                    category      VARCHAR(50),
                    quantity      INTEGER DEFAULT 0,
                    price         DECIMAL(10,2) DEFAULT 0.00,
                    reorder_level INTEGER DEFAULT 10,
                    supplier_id   INTEGER REFERENCES suppliers(supplier_id),
                    purchase_date DATE,
                    status        VARCHAR(20) DEFAULT 'Active'
                )""");

            // Stock Movements
            s.execute("""
                CREATE TABLE IF NOT EXISTS stock_movements (
                    movement_id   INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id    INTEGER NOT NULL REFERENCES products(product_id),
                    movement_type VARCHAR(20) NOT NULL,
                    quantity      INTEGER NOT NULL,
                    movement_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    user_id       INTEGER REFERENCES users(user_id),
                    notes         TEXT
                )""");

            // Alerts
            s.execute("""
                CREATE TABLE IF NOT EXISTS alerts (
                    alert_id      INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id    INTEGER REFERENCES products(product_id),
                    alert_type    VARCHAR(50) NOT NULL,
                    message       TEXT,
                    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
                    is_resolved   INTEGER DEFAULT 0
                )""");

            // Seed if empty
            try (ResultSet rs = s.executeQuery("SELECT COUNT(*) FROM users")) {
                if (rs.next() && rs.getInt(1) == 0) seedData(conn);
            }

        } catch (Exception e) {
            throw new RuntimeException("DB init failed: " + e.getMessage(), e);
        }
    }

    private static void seedData(Connection conn) throws Exception {
        // Users
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO users (username, password, role) VALUES (?, ?, ?)")) {
            for (String[] u : new String[][]{
                {"admin",    "admin123",   "Admin"},
                {"manager",  "manager123", "Inventory Manager"},
                {"staff1",   "staff123",   "Store Staff"},
            }) {
                ps.setString(1, u[0]); ps.setString(2, u[1]); ps.setString(3, u[2]);
                ps.executeUpdate();
            }
        }

        // Suppliers
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO suppliers (supplier_name, contact_info, email, address) VALUES (?, ?, ?, ?)")) {
            for (String[] sup : new String[][]{
                {"TechParts Ltd",    "+44 7700 900001", "sales@techparts.com",  "London, UK"},
                {"Office Supplies Co","+44 7700 900002","info@officesup.com",   "Manchester, UK"},
                {"Global Hardware",  "+44 7700 900003", "gh@globalhw.com",      "Birmingham, UK"},
            }) {
                ps.setString(1, sup[0]); ps.setString(2, sup[1]);
                ps.setString(3, sup[2]); ps.setString(4, sup[3]);
                ps.executeUpdate();
            }
        }

        // Products
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO products (product_name, category, quantity, price, reorder_level, supplier_id, purchase_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")) {
            Object[][] prods = {
                {"Laptop",           "Electronics", 45,  899.99, 10, 1, "2025-01-10", "Active"},
                {"Wireless Mouse",   "Electronics", 8,    24.99, 15, 1, "2025-01-15", "Active"},
                {"Office Chair",     "Furniture",   30,  149.99, 5,  2, "2025-02-01", "Active"},
                {"A4 Paper (Ream)",  "Stationery",  4,     5.99, 20, 2, "2025-02-10", "Active"},
                {"USB-C Hub",        "Electronics", 0,    39.99, 10, 1, "2025-03-01", "Active"},
                {"Desk Lamp",        "Furniture",   18,   34.99, 8,  2, "2025-03-05", "Active"},
                {"Keyboard",         "Electronics", 6,    59.99, 12, 1, "2025-03-10", "Active"},
                {"Stapler",          "Stationery",  25,    8.99, 10, 2, "2025-03-15", "Active"},
                {"Monitor 24\"",     "Electronics", 12,  299.99, 5,  1, "2025-04-01", "Active"},
                {"Whiteboard",       "Furniture",   3,    89.99, 5,  3, "2025-04-05", "Active"},
                {"Drill Set",        "Hardware",    15,   79.99, 8,  3, "2025-04-10", "Active"},
                {"Safety Gloves",    "Hardware",    2,    12.99, 20, 3, "2025-04-15", "Active"},
            };
            for (Object[] p : prods) {
                ps.setString(1, (String)p[0]); ps.setString(2, (String)p[1]);
                ps.setInt(3, (int)p[2]);       ps.setDouble(4, (double)p[3]);
                ps.setInt(5, (int)p[4]);       ps.setInt(6, (int)p[5]);
                ps.setString(7, (String)p[6]); ps.setString(8, (String)p[7]);
                ps.executeUpdate();
            }
        }

        // Stock movements
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO stock_movements (product_id, movement_type, quantity, movement_date, user_id, notes) VALUES (?, ?, ?, ?, ?, ?)")) {
            Object[][] mvs = {
                {1, "IN",  45, "2025-01-10 09:00:00", 2, "Initial stock"},
                {1, "OUT", 5,  "2025-02-01 10:30:00", 3, "Issued to IT Dept"},
                {2, "IN",  20, "2025-01-15 11:00:00", 2, "Initial stock"},
                {2, "OUT", 12, "2025-03-01 14:00:00", 3, "Sold — low stock warning"},
                {3, "IN",  30, "2025-02-01 09:30:00", 2, "Initial stock"},
                {4, "IN",  25, "2025-02-10 10:00:00", 2, "Initial stock"},
                {4, "OUT", 21, "2025-04-01 09:00:00", 3, "Monthly usage"},
                {5, "IN",  10, "2025-03-01 08:00:00", 2, "Initial stock"},
                {5, "OUT", 10, "2025-04-10 11:00:00", 3, "Fully depleted — out of stock"},
            };
            for (Object[] m : mvs) {
                ps.setInt(1, (int)m[0]); ps.setString(2, (String)m[1]);
                ps.setInt(3, (int)m[2]); ps.setString(4, (String)m[3]);
                ps.setInt(5, (int)m[4]); ps.setString(6, (String)m[5]);
                ps.executeUpdate();
            }
        }

        // Seed alerts for low/out-of-stock products
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO alerts (product_id, alert_type, message) VALUES (?, ?, ?)")) {
            Object[][] alerts = {
                {2,  "Low Stock",    "Wireless Mouse is below reorder level (8 < 15)"},
                {4,  "Low Stock",    "A4 Paper is critically low (4 < 20)"},
                {5,  "Out of Stock", "USB-C Hub is out of stock (0 units)"},
                {10, "Low Stock",    "Whiteboard stock is low (3 < 5)"},
                {12, "Low Stock",    "Safety Gloves critically low (2 < 20)"},
            };
            for (Object[] a : alerts) {
                ps.setInt(1, (int)a[0]); ps.setString(2, (String)a[1]);
                ps.setString(3, (String)a[2]); ps.executeUpdate();
            }
        }
    }
}
