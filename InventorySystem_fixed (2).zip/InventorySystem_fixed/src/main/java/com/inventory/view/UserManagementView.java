package com.inventory.view;

import com.inventory.controller.Controllers;
import com.inventory.controller.UserController;
import com.inventory.model.User;
import com.inventory.util.AlertHelper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.util.List;

public class UserManagementView {
    private BorderPane root;
    private TableView<User> table;
    private final UserController ctrl = Controllers.user();

    public UserManagementView() {
        root = new BorderPane();
        root.getStyleClass().add("page-content");
        root.setPadding(new Insets(28));

        VBox header = new VBox(4);
        Label title = new Label("User Management");
        title.getStyleClass().add("page-title");
        Label sub = new Label("Create, edit and manage system user accounts");
        sub.getStyleClass().add("page-subtitle");
        header.getChildren().addAll(title, sub);

        HBox toolbar = new HBox(10);
        toolbar.setAlignment(Pos.CENTER_LEFT);
        toolbar.setPadding(new Insets(14, 0, 14, 0));
        Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);

        Button addBtn = new Button("+ Add User");
        addBtn.getStyleClass().add("primary-btn");
        addBtn.setOnAction(e -> showForm(null));
        toolbar.getChildren().addAll(sp, addBtn);

        table = buildTable();
        VBox content = new VBox(0, header, toolbar, table);
        VBox.setVgrow(table, Priority.ALWAYS);
        root.setCenter(content);
        refresh();
    }

    private TableView<User> buildTable() {
        TableView<User> tv = new TableView<>();
        tv.getStyleClass().add("data-table");
        tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<User, String> roleCol = new TableColumn<>("Role");
        roleCol.setCellValueFactory(new PropertyValueFactory<>("role"));
        roleCol.setPrefWidth(160);
        roleCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setGraphic(null); return; }
                Label badge = new Label(item);
                badge.getStyleClass().add(
                    "Admin".equals(item)               ? "badge-danger" :
                    "Inventory Manager".equals(item)   ? "badge-info"   : "badge-success");
                setGraphic(badge); setText(null);
            }
        });

        TableColumn<User, Void> actionCol = new TableColumn<>("Actions");
        actionCol.setPrefWidth(160);
        actionCol.setCellFactory(c -> new TableCell<>() {
            final Button editBtn = new Button("Edit");
            final Button delBtn  = new Button("Delete");
            final HBox box = new HBox(6, editBtn, delBtn);
            {
                editBtn.getStyleClass().add("action-btn-edit");
                delBtn.getStyleClass().add("action-btn-delete");
                box.setAlignment(Pos.CENTER);
                editBtn.setOnAction(e -> showForm(getTableView().getItems().get(getIndex())));
                delBtn.setOnAction(e -> {
                    User u = getTableView().getItems().get(getIndex());
                    if (AlertHelper.confirm("Delete User", "Delete user \"" + u.getUsername() + "\"?")) {
                        ctrl.delete(u.getUserId()); refresh();
                    }
                });
            }
            @Override protected void updateItem(Void v, boolean empty) {
                super.updateItem(v, empty);
                setGraphic(empty ? null : box);
            }
        });

        tv.getColumns().addAll(
            col("ID",       "userId",   55),
            col("Username", "username", 200),
            roleCol,
            actionCol
        );
        return tv;
    }

    @SuppressWarnings("unchecked")
    private <T> TableColumn<User, T> col(String title, String prop, double w) {
        TableColumn<User, T> c = new TableColumn<>(title);
        c.setCellValueFactory(new PropertyValueFactory<>(prop)); c.setPrefWidth(w); return c;
    }

    private void showForm(User existing) {
        boolean isEdit = existing != null;
        Dialog<User> dlg = new Dialog<>();
        dlg.setTitle(isEdit ? "Edit User" : "Add User");

        ButtonType saveType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dlg.getDialogPane().getButtonTypes().addAll(saveType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(12); grid.setVgap(12); grid.setPadding(new Insets(20));

        TextField userF  = new TextField(isEdit ? existing.getUsername() : "");
        userF.setPrefWidth(240);
        PasswordField passF = new PasswordField();
        passF.setPrefWidth(240);
        if (isEdit) passF.setPromptText("Leave blank to keep existing");

        ComboBox<String> roleCmb = new ComboBox<>();
        roleCmb.getItems().addAll("Admin", "Inventory Manager", "Store Staff");
        roleCmb.setValue(isEdit ? existing.getRole() : "Store Staff");
        roleCmb.setPrefWidth(240);

        grid.add(new Label("Username:"), 0, 0); grid.add(userF,  1, 0);
        grid.add(new Label("Password:"), 0, 1); grid.add(passF,  1, 1);
        grid.add(new Label("Role:"),     0, 2); grid.add(roleCmb,1, 2);

        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getStylesheets().add(
            getClass().getResource("/com/inventory/css/style.css").toExternalForm());

        dlg.setResultConverter(btn -> {
            if (btn != saveType) return null;
            if (userF.getText().isBlank()) { AlertHelper.error("Validation", "Username is required."); return null; }
            if (!isEdit && passF.getText().isBlank()) { AlertHelper.error("Validation", "Password required for new user."); return null; }
            User u = isEdit ? existing : new User();
            u.setUsername(userF.getText().trim());
            if (!passF.getText().isBlank()) u.setPassword(passF.getText());
            u.setRole(roleCmb.getValue());
            return u;
        });

        dlg.showAndWait().ifPresent(u -> {
            boolean ok = isEdit ? ctrl.update(u) : ctrl.add(u);
            if (ok) { AlertHelper.info("Success", isEdit ? "User updated." : "User added."); refresh(); }
            else AlertHelper.error("Error", "Operation failed.");
        });
    }

    private void refresh() { table.getItems().setAll(ctrl.getAll()); }
    public BorderPane getRoot() { return root; }
}
