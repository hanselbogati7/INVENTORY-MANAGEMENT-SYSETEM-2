package com.inventory.view;

import com.inventory.controller.Controllers;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class LoginView {
    private BorderPane root;

    public LoginView(Stage stage) {
        root = new BorderPane();
        root.getStyleClass().add("login-root");

        // Left brand panel
        VBox brand = new VBox(16);
        brand.getStyleClass().add("brand-panel");
        brand.setAlignment(Pos.CENTER);
        brand.setPrefWidth(370);

        Text icon = new Text("📦");
        icon.getStyleClass().add("brand-icon");
        Label title = new Label("Inventory\nManagement\nSystem");
        title.getStyleClass().add("brand-title");
        title.setAlignment(Pos.CENTER);
        Label tagline = new Label("Track · Monitor · Optimise");
        tagline.getStyleClass().add("brand-tagline");
        Label sub = new Label("CIS096-1  —  Saurav Bogati  —  2533511");
        sub.getStyleClass().add("brand-sub");
        brand.getChildren().addAll(icon, title, tagline, sub);
        root.setLeft(brand);

        // Right login form
        VBox form = new VBox(16);
        form.getStyleClass().add("login-form-panel");
        form.setAlignment(Pos.CENTER);
        form.setPadding(new Insets(60));

        Label loginTitle = new Label("Sign In");
        loginTitle.getStyleClass().add("login-title");
        Label loginSub = new Label("Enter your credentials to access the system");
        loginSub.getStyleClass().add("login-subtitle");

        Label userLbl = new Label("Username");
        userLbl.getStyleClass().add("field-label");
        TextField userField = new TextField();
        userField.setPromptText("e.g. admin, manager, staff1");
        userField.getStyleClass().add("login-field");

        Label passLbl = new Label("Password");
        passLbl.getStyleClass().add("field-label");
        PasswordField passField = new PasswordField();
        passField.setPromptText("Enter password");
        passField.getStyleClass().add("login-field");

        Label errLbl = new Label();
        errLbl.getStyleClass().add("error-label");
        errLbl.setVisible(false);

        Button loginBtn = new Button("Sign In");
        loginBtn.getStyleClass().add("login-btn");
        loginBtn.setPrefWidth(300);

        VBox hints = new VBox(4);
        hints.getStyleClass().add("hint-box");
        for (String s : new String[]{
            "Demo Credentials:",
            "Admin:    admin / admin123",
            "Manager:  manager / manager123",
            "Staff:    staff1 / staff123"}) {
            Label l = new Label(s);
            l.getStyleClass().add("hint-text");
            hints.getChildren().add(l);
        }

        form.getChildren().addAll(loginTitle, loginSub, userLbl, userField,
            passLbl, passField, errLbl, loginBtn, hints);
        root.setCenter(form);

        var ctrl = Controllers.login(stage);
        loginBtn.setOnAction(e -> {
            String err = ctrl.login(userField.getText().trim(), passField.getText().trim());
            if (err != null) { errLbl.setText(err); errLbl.setVisible(true); }
            else errLbl.setVisible(false);
        });
        passField.setOnAction(e -> loginBtn.fire());
    }

    public BorderPane getRoot() { return root; }
}
