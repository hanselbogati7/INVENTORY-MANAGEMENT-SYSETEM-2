package com.inventory.view;

import com.inventory.controller.Controllers;
import com.inventory.controller.StockController;
import com.inventory.dao.ProductDAO;
import com.inventory.model.*;
import com.inventory.util.AlertHelper;
import com.inventory.util.Session;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.util.List;

public class StockMovementView {
    private BorderPane root;
    private TableView<StockMovement> table;
    private final StockController ctrl = Controllers.stock();

    public StockMovementView() {
        root = new BorderPane();
        root.getStyleClass().add("page-content");
        root.setPadding(new Insets(28));

        VBox header = new VBox(4);
        Label title = new Label("Stock Movements");
        title.getStyleClass().add("page-title");
        Label sub = new Label("Track all stock IN and OUT transactions");
        sub.getStyleClass().add("page-subtitle");
        header.getChildren().addAll(title, sub);

        HBox toolbar = new HBox(10);
        toolbar.setAlignment(Pos.CENTER_LEFT);
        toolbar.setPadding(new Insets(14, 0, 14, 0));

        TextField search = new TextField();
        search.setPromptText("🔍  Search by product, type or notes...");
        search.setPrefWidth(300);
        search.getStyleClass().add("search-field");
        search.textProperty().addListener((obs, o, n) -> refresh(ctrl.search(n)));

        Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);
        toolbar.getChildren().add(search);
        toolbar.getChildren().add(sp);

        if (Session.getInstance().canUpdateStock()) {
            Button inBtn  = new Button("📥  Stock IN");
            inBtn.getStyleClass().addAll("primary-btn", "btn-success");
            Button outBtn = new Button("📤  Stock OUT");
            outBtn.getStyleClass().addAll("primary-btn", "btn-danger");
            inBtn.setOnAction(e  -> showForm("IN"));
            outBtn.setOnAction(e -> showForm("OUT"));
            toolbar.getChildren().addAll(inBtn, outBtn);
        }

        table = buildTable();
        VBox content = new VBox(0, header, toolbar, table);
        VBox.setVgrow(table, Priority.ALWAYS);
        root.setCenter(content);
        refresh(ctrl.getAll());
    }

    private TableView<StockMovement> buildTable() {
        TableView<StockMovement> tv = new TableView<>();
        tv.getStyleClass().add("data-table");
        tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<StockMovement, String> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(new PropertyValueFactory<>("movementType"));
        typeCol.setPrefWidth(80);
        typeCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setGraphic(null); return; }
                Label badge = new Label(item);
                badge.getStyleClass().add("IN".equals(item) ? "badge-success" : "badge-danger");
                setGraphic(badge); setText(null);
            }
        });

        tv.getColumns().addAll(
            smCol("ID",        "movementId",   60),
            smCol("Product",   "productName",  180),
            typeCol,
            smCol("Qty",       "quantity",     70),
            smCol("Date",      "movementDate", 165),
            smCol("Notes",     "notes",        220)
        );
        return tv;
    }

    @SuppressWarnings("unchecked")
    private <T> TableColumn<StockMovement, T> smCol(String title, String prop, double w) {
        TableColumn<StockMovement, T> c = new TableColumn<>(title);
        c.setCellValueFactory(new PropertyValueFactory<>(prop)); c.setPrefWidth(w); return c;
    }

    private void showForm(String type) {
        Dialog<StockMovement> dlg = new Dialog<>();
        dlg.setTitle("Stock " + type);
        dlg.setHeaderText("Record a stock " + ("IN".equals(type) ? "receipt" : "issue"));

        ButtonType saveType = new ButtonType("Confirm", ButtonBar.ButtonData.OK_DONE);
        dlg.getDialogPane().getButtonTypes().addAll(saveType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(12); grid.setVgap(12); grid.setPadding(new Insets(20));

        List<Product> products = new ProductDAO().getActive();
        ComboBox<Product> prodCmb = new ComboBox<>();
        prodCmb.getItems().addAll(products); prodCmb.setPrefWidth(280);
        if (!products.isEmpty()) prodCmb.setValue(products.get(0));

        Label stockInfo = new Label();
        stockInfo.setStyle("-fx-text-fill:#1E8449;-fx-font-weight:bold;");
        Runnable updateInfo = () -> {
            Product p = prodCmb.getValue();
            if (p != null) stockInfo.setText("Current Stock: " + p.getQuantity() + " units");
        };
        prodCmb.setOnAction(e -> updateInfo.run());
        updateInfo.run();

        TextField qtyF  = new TextField();
        qtyF.setPromptText("Enter quantity"); qtyF.setPrefWidth(280);
        TextField notesF = new TextField();
        notesF.setPromptText("Optional notes"); notesF.setPrefWidth(280);

        int row = 0;
        grid.add(new Label("Product:"),  0, row); grid.add(prodCmb,   1, row++);
        grid.add(new Label(""),          0, row); grid.add(stockInfo, 1, row++);
        grid.add(new Label("Quantity:"), 0, row); grid.add(qtyF,      1, row++);
        grid.add(new Label("Notes:"),    0, row); grid.add(notesF,    1, row++);

        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getStylesheets().add(
            getClass().getResource("/com/inventory/css/style.css").toExternalForm());

        dlg.setResultConverter(btn -> {
            if (btn != saveType) return null;
            if (prodCmb.getValue() == null) { AlertHelper.error("Validation", "Select a product."); return null; }
            int qty;
            try {
                qty = Integer.parseInt(qtyF.getText().trim());
                if (qty <= 0) throw new NumberFormatException();
            } catch (NumberFormatException e2) { AlertHelper.error("Validation", "Enter a valid positive quantity."); return null; }

            StockMovement m = new StockMovement();
            m.setProductId(prodCmb.getValue().getProductId());
            m.setMovementType(type);
            m.setQuantity(qty);
            m.setUserId(Session.getInstance().getCurrentUser().getUserId());
            m.setNotes(notesF.getText().trim());
            return m;
        });

        dlg.showAndWait().ifPresent(m -> {
            String err = ctrl.recordMovement(m);
            if (err == null) {
                AlertHelper.info("Success", "Stock " + type + " recorded successfully.");
                refresh(ctrl.getAll());
            } else {
                AlertHelper.error("Stock Error", err);
            }
        });
    }

    private void refresh(List<StockMovement> items) { table.getItems().setAll(items); }
    public BorderPane getRoot() { return root; }
}
