package com.inventory.view;

import com.inventory.util.Session;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class DashboardView {
    private BorderPane root;
    private StackPane contentArea;
    private Stage stage;

    public DashboardView(Stage stage) {
        this.stage = stage;
        root = new BorderPane();
        root.getStyleClass().add("dashboard-root");
        root.setLeft(buildSidebar());
        root.setTop(buildTopBar());
        contentArea = new StackPane();
        contentArea.getStyleClass().add("content-area");
        root.setCenter(contentArea);
        show(new DashboardHomeView().getRoot());
    }

    private VBox buildSidebar() {
        VBox sb = new VBox(3);
        sb.getStyleClass().add("sidebar");
        sb.setPrefWidth(215);
        sb.setPadding(new Insets(16, 8, 16, 8));

        VBox logo = new VBox(4);
        logo.setAlignment(Pos.CENTER);
        logo.setPadding(new Insets(8, 0, 18, 0));
        Text ic = new Text("📦"); ic.setStyle("-fx-font-size:30px;");
        Label lbl = new Label("IMS"); lbl.getStyleClass().add("sidebar-logo");
        logo.getChildren().addAll(ic, lbl);

        sb.getChildren().add(logo);
        sb.getChildren().add(new Separator());
        sb.getChildren().add(sectionLbl("MAIN"));
        sb.getChildren().add(navBtn("🏠  Dashboard",       () -> show(new DashboardHomeView().getRoot())));
        sb.getChildren().add(navBtn("📦  Products",         () -> show(new ProductView().getRoot())));
        sb.getChildren().add(navBtn("🔄  Stock Movements",  () -> show(new StockMovementView().getRoot())));
        sb.getChildren().add(navBtn("🔔  Alerts",           () -> show(new AlertView().getRoot())));
        sb.getChildren().add(new Separator());
        sb.getChildren().add(sectionLbl("MANAGEMENT"));
        sb.getChildren().add(navBtn("🏭  Suppliers",        () -> show(new SupplierView().getRoot())));
        if (Session.getInstance().isAdmin()) {
            sb.getChildren().add(navBtn("👤  User Management", () -> show(new UserManagementView().getRoot())));
        }

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        sb.getChildren().add(spacer);

        Button logoutBtn = new Button("🚪  Logout");
        logoutBtn.getStyleClass().add("logout-btn");
        logoutBtn.setMaxWidth(Double.MAX_VALUE);
        logoutBtn.setOnAction(e -> logout());
        sb.getChildren().add(logoutBtn);
        return sb;
    }

    private HBox buildTopBar() {
        HBox bar = new HBox();
        bar.getStyleClass().add("top-bar");
        bar.setPadding(new Insets(14, 20, 14, 20));
        bar.setAlignment(Pos.CENTER_LEFT);

        Label title = new Label("Inventory Management System");
        title.getStyleClass().add("top-bar-title");
        Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);
        String info = Session.getInstance().getCurrentUser().getUsername()
                    + "  ·  " + Session.getInstance().getCurrentUser().getRole();
        Label user = new Label("👤  " + info);
        user.getStyleClass().add("top-bar-user");
        bar.getChildren().addAll(title, sp, user);
        return bar;
    }

    private Button navBtn(String text, Runnable action) {
        Button b = new Button(text);
        b.getStyleClass().add("nav-btn");
        b.setMaxWidth(Double.MAX_VALUE);
        b.setOnAction(e -> action.run());
        return b;
    }

    private Label sectionLbl(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("sidebar-section-label");
        VBox.setMargin(l, new Insets(8, 0, 4, 8));
        return l;
    }

    public void show(javafx.scene.Node node) {
        contentArea.getChildren().setAll(node);
    }

    private void logout() {
        Session.getInstance().logout();
        LoginView lv = new LoginView(stage);
        Scene sc = new Scene(lv.getRoot(), 960, 600);
        sc.getStylesheets().add(
            getClass().getResource("/com/inventory/css/style.css").toExternalForm());
        stage.setScene(sc);
        stage.setWidth(960); stage.setHeight(600); stage.centerOnScreen();
    }

    public BorderPane getRoot() { return root; }
}
