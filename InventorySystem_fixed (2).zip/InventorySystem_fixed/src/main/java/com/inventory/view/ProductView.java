package com.inventory.view;

import com.inventory.controller.Controllers;
import com.inventory.controller.ProductController;
import com.inventory.dao.SupplierDAO;
import com.inventory.model.Product;
import com.inventory.model.Supplier;
import com.inventory.util.AlertHelper;
import com.inventory.util.Session;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.util.List;

public class ProductView {
    private BorderPane root;
    private TableView<Product> table;
    private final ProductController ctrl = Controllers.product();

    public ProductView() {
        root = new BorderPane();
        root.getStyleClass().add("page-content");
        root.setPadding(new Insets(28));

        VBox header = new VBox(4);
        Label title = new Label("Product Management");
        title.getStyleClass().add("page-title");
        Label sub = new Label("Add, edit, search and archive inventory items");
        sub.getStyleClass().add("page-subtitle");
        header.getChildren().addAll(title, sub);

        HBox toolbar = new HBox(10);
        toolbar.setAlignment(Pos.CENTER_LEFT);
        toolbar.setPadding(new Insets(14, 0, 14, 0));

        TextField search = new TextField();
        search.setPromptText("🔍  Search by name, category or ID...");
        search.setPrefWidth(320);
        search.getStyleClass().add("search-field");
        search.textProperty().addListener((obs, o, n) -> refresh(ctrl.search(n)));

        Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);
        toolbar.getChildren().add(search);
        toolbar.getChildren().add(sp);

        if (Session.getInstance().canManageProducts()) {
            Button addBtn = new Button("+ Add Product");
            addBtn.getStyleClass().add("primary-btn");
            addBtn.setOnAction(e -> showForm(null));
            toolbar.getChildren().add(addBtn);
        }

        table = buildTable();
        VBox content = new VBox(0, header, toolbar, table);
        VBox.setVgrow(table, Priority.ALWAYS);
        root.setCenter(content);
        refresh(ctrl.getActive());
    }

    private TableView<Product> buildTable() {
        TableView<Product> tv = new TableView<>();
        tv.getStyleClass().add("data-table");
        tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        tv.getColumns().addAll(
            col("ID",           "productId",    60),
            col("Product Name", "productName",  170),
            col("Category",     "category",     110),
            col("Supplier",     "supplierName", 140),
            col("Price (£)",    "price",        90),
            col("Reorder Lvl",  "reorderLevel", 100),
            qtyCol(),
            stockStatusCol(),
            col("Purchase Date","purchaseDate", 120),
            actionCol()
        );
        return tv;
    }

    private TableColumn<Product, Integer> qtyCol() {
        TableColumn<Product, Integer> c = new TableColumn<>("Qty");
        c.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        c.setPrefWidth(70);
        c.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Integer item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(String.valueOf(item));
                Product p = getTableView().getItems().get(getIndex());
                if (p.isOutOfStock())     setStyle("-fx-text-fill:#E74C3C;-fx-font-weight:bold;");
                else if (p.isLowStock())  setStyle("-fx-text-fill:#E67E22;-fx-font-weight:bold;");
                else                      setStyle("-fx-text-fill:#1E8449;-fx-font-weight:bold;");
            }
        });
        return c;
    }

    private TableColumn<Product, String> stockStatusCol() {
        TableColumn<Product, String> c = new TableColumn<>("Stock Status");
        c.setCellValueFactory(new PropertyValueFactory<>("stockStatus"));
        c.setPrefWidth(110);
        c.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setGraphic(null); return; }
                Label badge = new Label(item);
                badge.getStyleClass().add(
                    "Out of Stock".equals(item) ? "badge-danger" :
                    "Low Stock".equals(item)    ? "badge-warning" : "badge-success");
                setGraphic(badge); setText(null);
            }
        });
        return c;
    }

    private TableColumn<Product, Void> actionCol() {
        TableColumn<Product, Void> c = new TableColumn<>("Actions");
        c.setPrefWidth(Session.getInstance().canManageProducts() ? 180 : 80);
        c.setCellFactory(col -> new TableCell<>() {
            final Button viewBtn    = new Button("View");
            final Button editBtn    = new Button("Edit");
            final Button archiveBtn = new Button("Archive");
            final HBox box;
            {
                viewBtn.getStyleClass().add("action-btn-edit");
                editBtn.getStyleClass().add("action-btn-edit");
                archiveBtn.getStyleClass().add("action-btn-delete");
                if (Session.getInstance().canManageProducts())
                    box = new HBox(5, viewBtn, editBtn, archiveBtn);
                else
                    box = new HBox(5, viewBtn);
                box.setAlignment(Pos.CENTER);

                viewBtn.setOnAction(e -> showDetail(getTableView().getItems().get(getIndex())));
                editBtn.setOnAction(e -> showForm(getTableView().getItems().get(getIndex())));
                archiveBtn.setOnAction(e -> {
                    Product p = getTableView().getItems().get(getIndex());
                    if (AlertHelper.confirm("Archive Product", "Archive \"" + p.getProductName() + "\"? It will be hidden from active inventory.")) {
                        ctrl.archive(p.getProductId());
                        refresh(ctrl.getActive());
                    }
                });
            }
            @Override protected void updateItem(Void v, boolean empty) {
                super.updateItem(v, empty);
                setGraphic(empty ? null : box);
            }
        });
        return c;
    }

    @SuppressWarnings("unchecked")
    private <T> TableColumn<Product, T> col(String title, String prop, double w) {
        TableColumn<Product, T> c = new TableColumn<>(title);
        c.setCellValueFactory(new PropertyValueFactory<>(prop)); c.setPrefWidth(w); return c;
    }

    private void showDetail(Product p) {
        Alert dlg = new Alert(Alert.AlertType.INFORMATION);
        dlg.setTitle("Product Details");
        dlg.setHeaderText(p.getProductName());
        dlg.setContentText(
            "ID: "           + p.getProductId()    + "\n" +
            "Category: "     + p.getCategory()     + "\n" +
            "Supplier: "     + p.getSupplierName() + "\n" +
            "Quantity: "     + p.getQuantity()     + "\n" +
            "Reorder Lvl: "  + p.getReorderLevel() + "\n" +
            "Price: £"       + String.format("%.2f", p.getPrice()) + "\n" +
            "Total Value: £" + String.format("%.2f", p.getInventoryValue()) + "\n" +
            "Stock Status: " + p.getStockStatus()  + "\n" +
            "Purchase Date: "+ p.getPurchaseDate() + "\n" +
            "Status: "       + p.getStatus()
        );
        dlg.showAndWait();
    }

    private void showForm(Product existing) {
        boolean isEdit = existing != null;
        Dialog<Product> dlg = new Dialog<>();
        dlg.setTitle(isEdit ? "Edit Product" : "Add New Product");
        dlg.setHeaderText(isEdit ? "Update product details" : "Enter product details");

        ButtonType saveType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dlg.getDialogPane().getButtonTypes().addAll(saveType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(12); grid.setVgap(12); grid.setPadding(new Insets(20));

        TextField nameF     = field(isEdit ? existing.getProductName() : "");
        TextField catF      = field(isEdit ? existing.getCategory() : "");
        TextField qtyF      = field(isEdit ? String.valueOf(existing.getQuantity()) : "0");
        TextField priceF    = field(isEdit ? String.format("%.2f", existing.getPrice()) : "0.00");
        TextField reorderF  = field(isEdit ? String.valueOf(existing.getReorderLevel()) : "10");
        TextField dateF     = field(isEdit ? existing.getPurchaseDate() : "");
        dateF.setPromptText("YYYY-MM-DD");

        List<Supplier> suppliers = new SupplierDAO().getAll();
        ComboBox<Supplier> supCmb = new ComboBox<>();
        supCmb.getItems().addAll(suppliers); supCmb.setPrefWidth(260);
        if (isEdit) suppliers.stream().filter(s -> s.getSupplierId() == existing.getSupplierId())
            .findFirst().ifPresent(supCmb::setValue);
        else if (!suppliers.isEmpty()) supCmb.setValue(suppliers.get(0));

        ComboBox<String> statusCmb = new ComboBox<>();
        statusCmb.getItems().addAll("Active", "Archived");
        statusCmb.setValue(isEdit ? existing.getStatus() : "Active");
        statusCmb.setPrefWidth(260);

        int row = 0;
        grid.add(new Label("Product Name:"), 0, row); grid.add(nameF,    1, row++);
        grid.add(new Label("Category:"),     0, row); grid.add(catF,     1, row++);
        grid.add(new Label("Quantity:"),     0, row); grid.add(qtyF,     1, row++);
        grid.add(new Label("Price (£):"),    0, row); grid.add(priceF,   1, row++);
        grid.add(new Label("Reorder Level:"),0, row); grid.add(reorderF, 1, row++);
        grid.add(new Label("Supplier:"),     0, row); grid.add(supCmb,   1, row++);
        grid.add(new Label("Purchase Date:"),0, row); grid.add(dateF,    1, row++);
        grid.add(new Label("Status:"),       0, row); grid.add(statusCmb,1, row++);

        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getStylesheets().add(
            getClass().getResource("/com/inventory/css/style.css").toExternalForm());

        dlg.setResultConverter(btn -> {
            if (btn != saveType) return null;
            if (nameF.getText().isBlank()) { AlertHelper.error("Validation", "Product name is required."); return null; }
            int qty, reorder; double price;
            try { qty = Integer.parseInt(qtyF.getText().trim()); } catch (Exception e2) { AlertHelper.error("Validation", "Quantity must be a whole number."); return null; }
            try { price = Double.parseDouble(priceF.getText().trim()); } catch (Exception e2) { AlertHelper.error("Validation", "Price must be a valid number."); return null; }
            try { reorder = Integer.parseInt(reorderF.getText().trim()); } catch (Exception e2) { AlertHelper.error("Validation", "Reorder level must be a whole number."); return null; }
            Product p = isEdit ? existing : new Product();
            p.setProductName(nameF.getText().trim()); p.setCategory(catF.getText().trim());
            p.setQuantity(qty); p.setPrice(price); p.setReorderLevel(reorder);
            p.setSupplierId(supCmb.getValue() != null ? supCmb.getValue().getSupplierId() : 0);
            p.setPurchaseDate(dateF.getText().trim()); p.setStatus(statusCmb.getValue());
            return p;
        });

        dlg.showAndWait().ifPresent(p -> {
            boolean ok = isEdit ? ctrl.update(p) : ctrl.add(p);
            if (ok) { AlertHelper.info("Success", isEdit ? "Product updated." : "Product added."); refresh(ctrl.getActive()); }
            else AlertHelper.error("Error", "Operation failed.");
        });
    }

    private TextField field(String val) {
        TextField tf = new TextField(val); tf.setPrefWidth(260); return tf;
    }
    private void refresh(List<Product> items) { table.getItems().setAll(items); }
    public BorderPane getRoot() { return root; }
}
