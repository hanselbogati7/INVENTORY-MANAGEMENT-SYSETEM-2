package com.inventory.view;

import com.inventory.controller.AlertController;
import com.inventory.controller.Controllers;
import com.inventory.model.Alert;
import com.inventory.util.AlertHelper;
import com.inventory.util.Session;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.util.List;

public class AlertView {
    private BorderPane root;
    private TableView<Alert> table;
    private final AlertController ctrl = Controllers.alert();

    public AlertView() {
        ctrl.sync(); // auto-generate alerts from current stock levels

        root = new BorderPane();
        root.getStyleClass().add("page-content");
        root.setPadding(new Insets(28));

        VBox header = new VBox(4);
        Label title = new Label("Alerts & Notifications");
        title.getStyleClass().add("page-title");
        Label sub = new Label("Low-stock and out-of-stock alerts generated automatically");
        sub.getStyleClass().add("page-subtitle");
        header.getChildren().addAll(title, sub);

        HBox toolbar = new HBox(10);
        toolbar.setAlignment(Pos.CENTER_LEFT);
        toolbar.setPadding(new Insets(14, 0, 14, 0));

        ToggleGroup tg = new ToggleGroup();
        RadioButton allRb    = new RadioButton("All");
        RadioButton activeRb = new RadioButton("Active Only");
        allRb.setToggleGroup(tg); activeRb.setToggleGroup(tg);
        activeRb.setSelected(true);
        allRb.setOnAction(e    -> refresh(ctrl.getAll()));
        activeRb.setOnAction(e -> refresh(ctrl.getActive()));

        Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);

        Button syncBtn = new Button("🔄  Sync Alerts");
        syncBtn.getStyleClass().add("primary-btn");
        syncBtn.setOnAction(e -> { ctrl.sync(); refresh(ctrl.getActive()); });

        toolbar.getChildren().addAll(allRb, activeRb, sp, syncBtn);

        table = buildTable();
        VBox content = new VBox(0, header, toolbar, table);
        VBox.setVgrow(table, Priority.ALWAYS);
        root.setCenter(content);
        refresh(ctrl.getActive());
    }

    private TableView<Alert> buildTable() {
        TableView<Alert> tv = new TableView<>();
        tv.getStyleClass().add("data-table");
        tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Alert, String> typeCol = new TableColumn<>("Alert Type");
        typeCol.setCellValueFactory(new PropertyValueFactory<>("alertType"));
        typeCol.setPrefWidth(130);
        typeCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setGraphic(null); return; }
                Label badge = new Label(item);
                badge.getStyleClass().add(
                    "Out of Stock".equals(item) ? "badge-danger" : "badge-warning");
                setGraphic(badge); setText(null);
            }
        });

        TableColumn<Alert, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("statusLabel"));
        statusCol.setPrefWidth(90);
        statusCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setGraphic(null); return; }
                Label badge = new Label(item);
                badge.getStyleClass().add("Resolved".equals(item) ? "badge-success" : "badge-danger");
                setGraphic(badge); setText(null);
            }
        });

        TableColumn<Alert, Void> actionCol = new TableColumn<>("Action");
        actionCol.setPrefWidth(110);
        actionCol.setCellFactory(c -> new TableCell<>() {
            final Button resolveBtn = new Button("✓ Resolve");
            {
                resolveBtn.getStyleClass().add("action-btn-success");
                resolveBtn.setOnAction(e -> {
                    Alert a = getTableView().getItems().get(getIndex());
                    if (!a.isResolved() && AlertHelper.confirm("Resolve Alert", "Mark this alert as resolved?")) {
                        ctrl.resolve(a.getAlertId());
                        refresh(ctrl.getActive());
                    }
                });
            }
            @Override protected void updateItem(Void v, boolean empty) {
                super.updateItem(v, empty);
                if (empty) { setGraphic(null); return; }
                Alert a = getTableView().getItems().get(getIndex());
                setGraphic(a.isResolved() ? null : resolveBtn);
            }
        });

        tv.getColumns().addAll(
            col("ID",        "alertId",     50),
            col("Product",   "productName", 180),
            typeCol,
            col("Message",   "message",     300),
            col("Created",   "createdAt",   155),
            statusCol,
            actionCol
        );
        return tv;
    }

    @SuppressWarnings("unchecked")
    private <T> TableColumn<Alert, T> col(String title, String prop, double w) {
        TableColumn<Alert, T> c = new TableColumn<>(title);
        c.setCellValueFactory(new PropertyValueFactory<>(prop)); c.setPrefWidth(w); return c;
    }

    private void refresh(List<Alert> items) { table.getItems().setAll(items); }
    public BorderPane getRoot() { return root; }
}
