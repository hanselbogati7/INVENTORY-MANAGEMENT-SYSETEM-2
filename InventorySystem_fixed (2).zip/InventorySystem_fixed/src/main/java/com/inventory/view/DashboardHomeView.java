package com.inventory.view;

import com.inventory.controller.Controllers;
import com.inventory.dao.AlertDAO;
import com.inventory.model.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

import java.util.List;

public class DashboardHomeView {
    private ScrollPane root;

    public DashboardHomeView() {
        var pc  = Controllers.product();
        var sc  = Controllers.stock();
        var ac  = Controllers.alert();

        VBox content = new VBox(24);
        content.setPadding(new Insets(28));
        content.getStyleClass().add("page-content");

        Label title = new Label("Dashboard Overview");
        title.getStyleClass().add("page-title");
        Label sub = new Label("Real-time inventory status at a glance");
        sub.getStyleClass().add("page-subtitle");

        // Stat cards
        int totalProducts  = Controllers.product().getAll().size();
        int lowStockCount  = Controllers.product().getLowStock().size();
        int activeAlerts   = new AlertDAO().getActiveCount();
        double totalValue  = new com.inventory.dao.ProductDAO().getTotalInventoryValue();

        HBox cards = new HBox(16);
        cards.getChildren().addAll(
            card("📦", "Total Products",  String.valueOf(totalProducts), "#1B4F72"),
            card("⚠️", "Low Stock Items", String.valueOf(lowStockCount), "#E67E22"),
            card("🔔", "Active Alerts",   String.valueOf(activeAlerts),  "#E74C3C"),
            card("💰", "Inventory Value", "£" + String.format("%.0f", totalValue), "#1E8449")
        );

        // Low stock panel
        VBox lowStockBox = new VBox(12);
        lowStockBox.getStyleClass().add("section-box");
        lowStockBox.setPadding(new Insets(20));

        HBox lsHeader = new HBox(10);
        lsHeader.setAlignment(Pos.CENTER_LEFT);
        Label lsTitle = new Label("⚠️  Low Stock & Out-of-Stock Items");
        lsTitle.getStyleClass().add("section-title");
        lsHeader.getChildren().add(lsTitle);

        TableView<Product> lsTable = new TableView<>();
        lsTable.getStyleClass().add("data-table");
        lsTable.setPrefHeight(200);
        lsTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        lsTable.getColumns().addAll(
            strCol("Product", "productName", 180),
            strCol("Category", "category", 120),
            intCol("Qty", "quantity", 70),
            intCol("Reorder Lvl", "reorderLevel", 100),
            statusCol()
        );
        lsTable.getItems().addAll(pc.getLowStock());
        lowStockBox.getChildren().addAll(lsHeader, lsTable);

        // Recent stock movements
        VBox recentBox = new VBox(12);
        recentBox.getStyleClass().add("section-box");
        recentBox.setPadding(new Insets(20));
        Label recTitle = new Label("🔄  Recent Stock Movements");
        recTitle.getStyleClass().add("section-title");

        TableView<StockMovement> smTable = new TableView<>();
        smTable.getStyleClass().add("data-table");
        smTable.setPrefHeight(220);
        smTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<StockMovement, String> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(new PropertyValueFactory<>("movementType"));
        typeCol.setPrefWidth(80);
        typeCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setGraphic(null); return; }
                Label badge = new Label(item);
                badge.getStyleClass().add("IN".equals(item) ? "badge-success" : "badge-danger");
                setGraphic(badge); setText(null);
            }
        });

        smTable.getColumns().addAll(
            smStrCol("Product", "productName", 180),
            typeCol,
            smIntCol("Qty", "quantity", 70),
            smStrCol("Date", "movementDate", 160),
            smStrCol("Notes", "notes", 200)
        );

        List<StockMovement> recent = new com.inventory.dao.StockMovementDAO().getRecent(10);
        smTable.getItems().addAll(recent);
        recentBox.getChildren().addAll(recTitle, smTable);

        content.getChildren().addAll(title, sub, cards, lowStockBox, recentBox);

        root = new ScrollPane(content);
        root.setFitToWidth(true);
        root.getStyleClass().add("scroll-pane");
    }

    private VBox card(String icon, String label, String value, String color) {
        VBox c = new VBox(8);
        c.getStyleClass().add("stat-card");
        c.setPadding(new Insets(20));
        c.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(c, Priority.ALWAYS);

        Text ic = new Text(icon); ic.setStyle("-fx-font-size:28px;");
        Label val = new Label(value);
        val.setStyle("-fx-font-size:28px;-fx-font-weight:bold;-fx-text-fill:" + color + ";");
        Label lbl = new Label(label); lbl.getStyleClass().add("stat-label");
        VBox txt = new VBox(2, val, lbl);
        HBox row = new HBox(12, ic, txt); row.setAlignment(Pos.CENTER_LEFT);
        Region bar = new Region();
        bar.setPrefHeight(4);
        bar.setStyle("-fx-background-color:" + color + ";-fx-background-radius:2;");
        c.getChildren().addAll(row, bar);
        return c;
    }

    @SuppressWarnings("unchecked")
    private <T> TableColumn<Product, T> strCol(String title, String prop, double w) {
        TableColumn<Product, T> c = new TableColumn<>(title);
        c.setCellValueFactory(new PropertyValueFactory<>(prop)); c.setPrefWidth(w); return c;
    }
    @SuppressWarnings("unchecked")
    private <T> TableColumn<Product, T> intCol(String title, String prop, double w) {
        return strCol(title, prop, w);
    }

    private TableColumn<Product, String> statusCol() {
        TableColumn<Product, String> c = new TableColumn<>("Status");
        c.setCellValueFactory(new PropertyValueFactory<>("stockStatus"));
        c.setPrefWidth(110);
        c.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setGraphic(null); return; }
                Label badge = new Label(item);
                badge.getStyleClass().add(
                    "Out of Stock".equals(item) ? "badge-danger" :
                    "Low Stock".equals(item)    ? "badge-warning" : "badge-success");
                setGraphic(badge); setText(null);
            }
        });
        return c;
    }

    @SuppressWarnings("unchecked")
    private <T> TableColumn<StockMovement, T> smStrCol(String title, String prop, double w) {
        TableColumn<StockMovement, T> c = new TableColumn<>(title);
        c.setCellValueFactory(new PropertyValueFactory<>(prop)); c.setPrefWidth(w); return c;
    }
    @SuppressWarnings("unchecked")
    private <T> TableColumn<StockMovement, T> smIntCol(String title, String prop, double w) {
        return smStrCol(title, prop, w);
    }

    public ScrollPane getRoot() { return root; }
}
