package com.inventory.view;

import com.inventory.controller.Controllers;
import com.inventory.controller.SupplierController;
import com.inventory.model.Supplier;
import com.inventory.util.AlertHelper;
import com.inventory.util.Session;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.util.List;

public class SupplierView {
    private BorderPane root;
    private TableView<Supplier> table;
    private final SupplierController ctrl = Controllers.supplier();

    public SupplierView() {
        root = new BorderPane();
        root.getStyleClass().add("page-content");
        root.setPadding(new Insets(28));

        VBox header = new VBox(4);
        Label title = new Label("Supplier Management");
        title.getStyleClass().add("page-title");
        Label sub = new Label("Manage product suppliers and contact information");
        sub.getStyleClass().add("page-subtitle");
        header.getChildren().addAll(title, sub);

        HBox toolbar = new HBox(10);
        toolbar.setAlignment(Pos.CENTER_LEFT);
        toolbar.setPadding(new Insets(14, 0, 14, 0));
        Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);
        toolbar.getChildren().add(sp);

        if (Session.getInstance().canManageProducts()) {
            Button addBtn = new Button("+ Add Supplier");
            addBtn.getStyleClass().add("primary-btn");
            addBtn.setOnAction(e -> showForm(null));
            toolbar.getChildren().add(addBtn);
        }

        table = buildTable();
        VBox content = new VBox(0, header, toolbar, table);
        VBox.setVgrow(table, Priority.ALWAYS);
        root.setCenter(content);
        refresh();
    }

    private TableView<Supplier> buildTable() {
        TableView<Supplier> tv = new TableView<>();
        tv.getStyleClass().add("data-table");
        tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Supplier, Void> actionCol = new TableColumn<>("Actions");
        actionCol.setPrefWidth(150);
        actionCol.setCellFactory(c -> new TableCell<>() {
            final Button editBtn = new Button("Edit");
            final Button delBtn  = new Button("Delete");
            final HBox box = new HBox(6, editBtn, delBtn);
            {
                editBtn.getStyleClass().add("action-btn-edit");
                delBtn.getStyleClass().add("action-btn-delete");
                box.setAlignment(Pos.CENTER);
                editBtn.setOnAction(e -> showForm(getTableView().getItems().get(getIndex())));
                delBtn.setOnAction(e -> {
                    Supplier s = getTableView().getItems().get(getIndex());
                    if (AlertHelper.confirm("Delete Supplier", "Delete supplier \"" + s.getSupplierName() + "\"?")) {
                        if (!ctrl.delete(s.getSupplierId()))
                            AlertHelper.error("Error", "Cannot delete — supplier may have linked products.");
                        else refresh();
                    }
                });
            }
            @Override protected void updateItem(Void v, boolean empty) {
                super.updateItem(v, empty);
                setGraphic(empty ? null : (Session.getInstance().canManageProducts() ? box : null));
            }
        });

        tv.getColumns().addAll(
            col("ID",           "supplierId",   60),
            col("Supplier Name","supplierName", 200),
            col("Contact",      "contactInfo",  150),
            col("Email",        "email",        190),
            col("Address",      "address",      220),
            actionCol
        );
        return tv;
    }

    @SuppressWarnings("unchecked")
    private <T> TableColumn<Supplier, T> col(String title, String prop, double w) {
        TableColumn<Supplier, T> c = new TableColumn<>(title);
        c.setCellValueFactory(new PropertyValueFactory<>(prop)); c.setPrefWidth(w); return c;
    }

    private void showForm(Supplier existing) {
        boolean isEdit = existing != null;
        Dialog<Supplier> dlg = new Dialog<>();
        dlg.setTitle(isEdit ? "Edit Supplier" : "Add Supplier");

        ButtonType saveType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dlg.getDialogPane().getButtonTypes().addAll(saveType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(12); grid.setVgap(12); grid.setPadding(new Insets(20));

        TextField nameF    = field(isEdit ? existing.getSupplierName() : "");
        TextField contactF = field(isEdit ? existing.getContactInfo()  : "");
        TextField emailF   = field(isEdit ? existing.getEmail()        : "");
        TextField addrF    = field(isEdit ? existing.getAddress()      : "");

        grid.add(new Label("Supplier Name:"), 0, 0); grid.add(nameF,    1, 0);
        grid.add(new Label("Contact:"),       0, 1); grid.add(contactF, 1, 1);
        grid.add(new Label("Email:"),         0, 2); grid.add(emailF,   1, 2);
        grid.add(new Label("Address:"),       0, 3); grid.add(addrF,    1, 3);

        dlg.getDialogPane().setContent(grid);
        dlg.getDialogPane().getStylesheets().add(
            getClass().getResource("/com/inventory/css/style.css").toExternalForm());

        dlg.setResultConverter(btn -> {
            if (btn != saveType) return null;
            if (nameF.getText().isBlank()) { AlertHelper.error("Validation", "Supplier name is required."); return null; }
            Supplier s = isEdit ? existing : new Supplier();
            s.setSupplierName(nameF.getText().trim());
            s.setContactInfo(contactF.getText().trim());
            s.setEmail(emailF.getText().trim());
            s.setAddress(addrF.getText().trim());
            return s;
        });

        dlg.showAndWait().ifPresent(s -> {
            boolean ok = isEdit ? ctrl.update(s) : ctrl.add(s);
            if (ok) { AlertHelper.info("Success", isEdit ? "Supplier updated." : "Supplier added."); refresh(); }
            else AlertHelper.error("Error", "Operation failed.");
        });
    }

    private TextField field(String val) {
        TextField tf = new TextField(val); tf.setPrefWidth(260); return tf;
    }
    private void refresh() { table.getItems().setAll(ctrl.getAll()); }
    public BorderPane getRoot() { return root; }
}
