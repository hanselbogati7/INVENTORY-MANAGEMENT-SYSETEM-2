package com.inventory.controller;

import com.inventory.dao.ProductDAO;
import com.inventory.model.Product;
import java.util.List;

public class ProductController {
    private final ProductDAO dao = new ProductDAO();

    public List<Product> getAll()          { return dao.getAll(); }
    public List<Product> getActive()       { return dao.getActive(); }
    public List<Product> search(String kw) { return kw == null || kw.isBlank() ? dao.getActive() : dao.search(kw); }
    public List<Product> getLowStock()     { return dao.getLowStock(); }
    public boolean add(Product p)          { return dao.insert(p); }
    public boolean update(Product p)       { return dao.update(p); }
    public boolean archive(int id)         { return dao.archive(id); }
}
