package com.inventory.controller;

import com.inventory.dao.UserDAO;
import com.inventory.model.User;
import com.inventory.util.Session;
import com.inventory.view.DashboardView;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class LoginController {
    private final UserDAO dao = new UserDAO();
    private final Stage stage;

    public LoginController(Stage stage) { this.stage = stage; }

    public String login(String username, String password) {
        if (username.isBlank() || password.isBlank()) return "Username and password are required.";
        User u = dao.authenticate(username, password);
        if (u == null) return "Invalid credentials. Please try again.";
        Session.getInstance().setCurrentUser(u);
        DashboardView dash = new DashboardView(stage);
        Scene scene = new Scene(dash.getRoot(), 1200, 750);
        scene.getStylesheets().add(getClass().getResource("/com/inventory/css/style.css").toExternalForm());
        stage.setScene(scene);
        stage.setWidth(1200); stage.setHeight(750); stage.centerOnScreen();
        return null;
    }
}
