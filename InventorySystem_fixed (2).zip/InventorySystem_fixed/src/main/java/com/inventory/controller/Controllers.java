package com.inventory.controller;

import javafx.stage.Stage;

public class Controllers {
    public static LoginController    login(Stage s) { return new LoginController(s); }
    public static ProductController  product()      { return new ProductController(); }
    public static StockController    stock()        { return new StockController(); }
    public static SupplierController supplier()     { return new SupplierController(); }
    public static AlertController    alert()        { return new AlertController(); }
    public static UserController     user()         { return new UserController(); }
}
