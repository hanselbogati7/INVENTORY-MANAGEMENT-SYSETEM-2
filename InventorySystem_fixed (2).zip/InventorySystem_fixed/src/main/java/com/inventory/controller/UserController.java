package com.inventory.controller;

import com.inventory.dao.UserDAO;
import com.inventory.model.User;
import java.util.List;

public class UserController {
    private final UserDAO dao = new UserDAO();

    public List<User> getAll()    { return dao.getAll(); }
    public boolean add(User u)    { return dao.insert(u); }
    public boolean update(User u) { return dao.update(u); }
    public boolean delete(int id) { return dao.delete(id); }
}
