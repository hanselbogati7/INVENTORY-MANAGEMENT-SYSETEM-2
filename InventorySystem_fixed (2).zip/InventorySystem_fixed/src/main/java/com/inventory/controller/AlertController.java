package com.inventory.controller;

import com.inventory.dao.AlertDAO;
import com.inventory.model.Alert;
import java.util.List;

public class AlertController {
    private final AlertDAO dao = new AlertDAO();

    public List<Alert> getAll()    { return dao.getAll(); }
    public List<Alert> getActive() { return dao.getActive(); }
    public boolean resolve(int id) { return dao.resolve(id); }
    public void sync()             { dao.syncAlerts(); }
}
