package com.inventory.controller;

import com.inventory.dao.AlertDAO;
import com.inventory.dao.ProductDAO;
import com.inventory.dao.StockMovementDAO;
import com.inventory.model.Product;
import com.inventory.model.StockMovement;
import java.util.List;

public class StockController {
    private final StockMovementDAO smDAO = new StockMovementDAO();
    private final ProductDAO       pDAO  = new ProductDAO();
    private final AlertDAO         aDAO  = new AlertDAO();

    public List<StockMovement> getAll()         { return smDAO.getAll(); }
    public List<StockMovement> search(String k) { return k == null || k.isBlank() ? smDAO.getAll() : smDAO.search(k); }

    public String recordMovement(StockMovement m) {
        Product p = pDAO.getById(m.getProductId());
        if (p == null) return "Product not found.";
        boolean ok = "IN".equals(m.getMovementType()) ? p.addStock(m.getQuantity()) : p.removeStock(m.getQuantity());
        if (!ok) return "OUT".equals(m.getMovementType())
            ? "Insufficient stock. Available: " + p.getQuantity() + " units." : "Invalid quantity.";
        pDAO.updateQuantity(p.getProductId(), p.getQuantity());
        smDAO.insert(m);
        aDAO.syncAlerts();
        return null;
    }
}
