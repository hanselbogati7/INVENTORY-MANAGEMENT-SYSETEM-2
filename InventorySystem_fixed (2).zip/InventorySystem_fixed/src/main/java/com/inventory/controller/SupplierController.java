package com.inventory.controller;

import com.inventory.dao.SupplierDAO;
import com.inventory.model.Supplier;
import java.util.List;

public class SupplierController {
    private final SupplierDAO dao = new SupplierDAO();

    public List<Supplier> getAll()    { return dao.getAll(); }
    public boolean add(Supplier s)    { return dao.insert(s); }
    public boolean update(Supplier s) { return dao.update(s); }
    public boolean delete(int id)     { return dao.delete(id); }
}
