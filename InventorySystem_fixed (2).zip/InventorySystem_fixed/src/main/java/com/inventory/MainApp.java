package com.inventory;

import com.inventory.database.DatabaseConnection;
import com.inventory.database.DatabaseInitializer;
import com.inventory.view.LoginView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        DatabaseInitializer.initialize();

        LoginView loginView = new LoginView(primaryStage);
        Scene scene = new Scene(loginView.getRoot(), 960, 600);
        scene.getStylesheets().add(
            getClass().getResource("/com/inventory/css/style.css").toExternalForm());

        primaryStage.setTitle("Inventory Management System");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(960);
        primaryStage.setMinHeight(600);
        primaryStage.show();
    }

    @Override
    public void stop() {
        DatabaseConnection.getInstance().closeConnection();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
