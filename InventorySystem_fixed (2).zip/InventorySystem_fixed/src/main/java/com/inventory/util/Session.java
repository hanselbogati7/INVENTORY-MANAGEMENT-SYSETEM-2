package com.inventory.util;

import com.inventory.model.User;

public class Session {
    private static Session instance;
    private User currentUser;

    private Session() {}
    public static Session getInstance() {
        if (instance == null) instance = new Session();
        return instance;
    }

    public User getCurrentUser()       { return currentUser; }
    public void setCurrentUser(User u) { this.currentUser = u; }
    public void logout()               { currentUser = null; }

    public boolean isAdmin()   { return currentUser != null && "Admin".equals(currentUser.getRole()); }
    public boolean isManager() { return currentUser != null && "Inventory Manager".equals(currentUser.getRole()); }
    public boolean isStaff()   { return currentUser != null && "Store Staff".equals(currentUser.getRole()); }
    public boolean canManageProducts() { return isAdmin() || isManager(); }
    public boolean canUpdateStock()    { return isAdmin() || isManager() || isStaff(); }
}
