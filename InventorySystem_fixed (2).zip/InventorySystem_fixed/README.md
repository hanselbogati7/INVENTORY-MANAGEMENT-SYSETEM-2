# Inventory Management System
**CIS096-1 — Principles of Programming and Data Structures**
**Saurav Bogati — Student ID: 2533511**
**University of Bedfordshire**

---

## Overview
A desktop application built with **Java 21 + JavaFX 21**, backed by an embedded **SQLite** database.
Implements **MVC + DAO + Singleton** design patterns with full OOP principles.

## Tech Stack
| Layer       | Technology        |
|-------------|-------------------|
| Language    | Java 21           |
| UI          | JavaFX 21         |
| Database    | SQLite (embedded) |
| Build       | Apache Maven 3.8+ |
| Architecture| MVC + DAO + Singleton |

## Project Structure
```
src/main/java/com/inventory/
├── MainApp.java
├── model/         User, Product, Supplier, StockMovement, Alert
├── dao/           UserDAO, ProductDAO, SupplierDAO, StockMovementDAO, AlertDAO
├── controller/    Controllers.java (Login, Product, Stock, Supplier, Alert, User)
├── view/          LoginView, DashboardView, DashboardHomeView,
│                  ProductView, StockMovementView, AlertView,
│                  SupplierView, UserManagementView
├── database/      DatabaseConnection (Singleton), DatabaseInitializer
└── util/          Session (Singleton), AlertHelper
```

## How to Run

### Prerequisites
- Java 21 JDK — https://adoptium.net/
- Apache Maven 3.8+ — https://maven.apache.org/

### Run
```bash
cd InventorySystem
mvn javafx:run
```

### Build fat JAR
```bash
mvn clean package
java -jar target/InventorySystem-1.0.0.jar
```

> On first launch, `inventory_system.db` is created automatically with 12 demo products,
> 3 suppliers, 3 users, stock movements and alerts.

## Demo Credentials
| Role              | Username  | Password     | Access                              |
|-------------------|-----------|--------------|-------------------------------------|
| Admin             | admin     | admin123     | Full access including User Management |
| Inventory Manager | manager   | manager123   | Products, stock, suppliers, alerts  |
| Store Staff       | staff1    | staff123     | View products, record stock movements |

## Features
- **Dashboard** — Live stats: total products, low stock count, active alerts, inventory value
- **Products** — Add, edit, archive; stock-status colour coding; supplier linking
- **Stock Movements** — Record IN/OUT with balance validation; auto-triggers alerts
- **Alerts** — Auto-generated for low/out-of-stock items; resolve workflow
- **Suppliers** — Full CRUD for supplier records
- **User Management** — Admin-only; role-based access (Admin / Inventory Manager / Store Staff)

## OOP Concepts
| Concept       | Implementation                                                  |
|---------------|-----------------------------------------------------------------|
| Encapsulation | Product.addStock() / removeStock() — quantity is private        |
| Inheritance   | User base class; role checked via Session.isAdmin() etc.        |
| Abstraction   | DAOs hide all SQL; controllers never write queries              |
| Polymorphism  | StockController dispatches addStock/removeStock by type string  |

## Data Structures
| Structure  | Where used                                          |
|------------|-----------------------------------------------------|
| ArrayList  | All DAO return types; TableView data source         |
| HashMap    | Session role caching                                |
| Queue      | Alert processing order (FIFO via created_at)        |
| SQL Tables | 5 normalised tables (3NF)                           |
